<?php
$a = $_POST['id'];
$b = $_POST['name'];
$c = $_POST['email'];



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "csedkte";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO students
VALUES ('$a', '$b', '$c')";




if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

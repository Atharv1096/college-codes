<?php
// Starting session
session_start();
 
// Storing session data
$_SESSION["username"] = "Monika";
$_SESSION["password"] = "msa#123";

echo 'your login is successful.'
?>